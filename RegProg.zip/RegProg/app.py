import shutil
import tkinter as tk
from tkinter import filedialog
import os
import openpyxl
import requests
import subprocess 

f = open("version.txt", "r")
version = f.read()


url = 'https://raw.githubusercontent.com/Aurution/RegProg/refs/heads/main/version.txt'
r = requests.get(url, allow_redirects=True)
onlineVersion = r.content.decode('utf-8').strip()

if onlineVersion == version:
    print("Systemet är uppdaterat")
else:
    print("Systemet måste uppdateras")
    os.startfile("update.exe")
    

root = tk.Tk()
root.withdraw()

def excelNew(path):
    regNr = []
    verksamLi = []

    print("Öppnar mall")
    Wb_obj = openpyxl.load_workbook("template.xlsx")
    Sheet_obj = Wb_obj.active
    print("Mall öppnad")

    while True:
        print("\nMata in ett registeringsnummer (skriv x för att avsluta): ")
        Number = input()
        if Number == "x" or Number == "X":
            print("Avslutar och sparar..")
            print(regNr)
            print(verksamLi)

            combined = list(zip(regNr, verksamLi))
            combined.sort(key=lambda x: x[0])
            regNr, verksamLi = zip(*combined)


            for i in range(len(regNr)):
                cell_obj = Sheet_obj.cell(row = (i+1), column = 1)
                cell_obj.value = regNr[i]
                cell_obj_verk = Sheet_obj.cell(row = (i+1), column = 2)
                cell_obj_verk.value = verksamLi[i]
            
            Wb_obj.save(path)
            break
        else:
            regNr.append(Number)
            print("Mata in verksamhet: ")
            Verksam = input()
            verksamLi.append(Verksam)


def main():
    print("Välkommen till RegProg!\n")
    print("Välj ett alternativ för att komma igång: \n")
    print(" 1. Redigera en fil (ur funktion) \n 2. Skapa en fil \n 3. Avsluta programmet")

    choice = input()
    if choice == "1":
        quit()
        print()
        file_path = filedialog.askopenfilename()
        excelcheck = file_path.find(".xlsx")
        if excelcheck == -1:
            print("Fil är inte .xlsx")
            quit()
        else:
            print(file_path)
    elif choice == "2":
        print()
        print("Välj ett namn till filen: ")
        name = input()
        print("Skapar " + name + ".xlsx")
        print("Den färdiga filen hittar du i mappen som programmet är i")
        excelNew((name + ".xlsx"))
    elif choice == "3":
        print("Avslutar..")
    else:
        print("Felaktig inmatning!\n\n\n")
        main()
main()